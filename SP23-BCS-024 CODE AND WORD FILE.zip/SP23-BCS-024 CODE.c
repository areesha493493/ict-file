#include<stdio.h>
#include<math.h>
#include<string.h>

int main()
{
int no=0,i=0,no_base=0; //the number is binary and octal ,exponent of number and base number
int rem=0,dec=0,len=0,value=0; // remainder(digit) ,decimal number , length of string , array

while(no!=-1){  //the loop ends at -1
printf("Enter the 2 for Binary number , 8 for Octal number and 16 for Hexadecimal number and -1 to exit the loop\n"); // input number from user
scanf("%d",&no_base);


switch(no_base){ //cases for binary , octal and Hexadecimal numbers

case 2 :

printf("Enter the binary number\n"); //if user enter binary number this case executes
scanf("%d",&no);

while(no!=0){ // to get digits in separated form
rem=no%10;

if(rem !=0 && rem!=1){
printf("number exceed base! number must be smaller than its base\n"); //condition for number validity
scanf("%d",&no);
}

dec = dec + rem * pow(2,i); //calculation of decimal number
no = no / 10;
i++;
}
printf("the decimal number is :%d\n",dec); //results

break;

case 8:

printf("Enter the Octal number\n"); // for octal number
scanf("%d",&no);

while(no!=0){
rem=no%10;  //digits separation in number

if(rem>=8){
printf("number exceed base! number must be smaller than its base ! enter the number again\n"); // number validity
scanf("%d",&no);

}

dec+=rem*pow(8,i); //decimal number calculation
no=no/10;
i++;
}
printf("the decimal number is :%d\n",dec); //results in decimal number

break;

case 16:

printf("Enter the Hexadecimal Number\n"); //for hexadecimal number
scanf(" %s",&no);


    char hexa[32]="2D"; //array to store digits of hexadecimal number
    int dec,i,c,digit; // decimal number ,counter , exponent, digits of number

    for(i=(strlen(hexa)-1);i>=0;i--){

    switch(hexa[i]){ //cases for A=10,B=11,C=12,D=13,E=14 and F=15

    case'A':
    case'a':
    digit=10;
    break;

    case'B':
    case'b':
    digit=11;
    break;

    case'C':
    case'c':
    digit=12;
    break;

    case'D':
    case'd':
    digit=13;
    break;

    case'E':
    case'e':
    digit=14;
    break;

    case'F':
    case'f':
    digit=15;
    break;

    default: // number other than 0-9 or character other than A-F
        digit=hexa[i]-0*30;
    }
    dec=dec+digit*pow(16,c); //decimal number calculation
    c++;
    }
    printf("dec no is %d",dec); //results
}
}
return 0; //main program ends here
}
